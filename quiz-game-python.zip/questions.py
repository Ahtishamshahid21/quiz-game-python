questions = [
    {"question": "What is the capital of Pakistan?", "options": ["Karachi", "Lahore", "Islamabad", "Peshawar"], "answer": "Islamabad"},
    {"question": "2 + 2 = ?", "options": ["3", "4", "5", "6"], "answer": "4"},
    {"question": "Python is ___?", "options": ["snake", "language", "fruit", "game"], "answer": "language"},
    {"question": "Which language is used for web development?", "options": ["Python", "C++", "HTML", "Assembly"], "answer": "HTML"},
    {"question": "Who developed Python?", "options": ["Guido van Rossum", "Bill Gates", "Linus Torvalds", "Mark Zuckerberg"], "answer": "Guido van Rossum"}
]
